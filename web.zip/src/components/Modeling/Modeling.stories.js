import { Modeling } from ".";

export default {
  title: "Components/Modeling",
  component: Modeling,
};

export const Default = {
  args: {
    className: {},
  },
};
