import { NavBar } from ".";

export default {
  title: "Components/NavBar",
  component: NavBar,
};

export const Default = {
  args: {
    className: {},
  },
};
