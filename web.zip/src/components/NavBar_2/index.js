export { NavBar_2 } from "./NavBar_2";
