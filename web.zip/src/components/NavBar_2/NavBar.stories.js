import { NavBar_2 } from ".";
import { NavBar_2 } from "./NavBar_2";

export default {
  title: "Components/NavBar_2",
  component: NavBar_2,
};

export const Default = {
  args: {
    className: {},
    maskGroup: "https://c.animaapp.com/jrXwmMSX/img/mask-group-13@2x.png",
  },
};
