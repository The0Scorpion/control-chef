import { BlockDiagram } from ".";

export default {
  title: "Components/BlockDiagram",
  component: BlockDiagram,
};

export const Default = {
  args: {
    className: {},
  },
};
