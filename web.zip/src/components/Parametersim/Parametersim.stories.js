import { Parametersnew } from ".";

export default {
  title: "Components/Parametersnew",
  component: Parametersnew,
};

export const Default = {
  args: {
    className: {},
  },
};
