import { NavLogWrapper } from ".";

export default {
  title: "Components/NavLogWrapper",
  component: NavLogWrapper,
};

export const Default = {
  args: {
    className: {},
  },
};
