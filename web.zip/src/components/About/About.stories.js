import { About } from ".";

export default {
  title: "Components/About",
  component: About,
};

export const Default = {
  args: {
    className: {},
  },
};
