import { Next } from ".";

export default {
  title: "Components/Next",
  component: Next,
};

export const Default = {
  args: {
    className: {},
  },
};
