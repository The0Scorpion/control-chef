import { SimulationStreaming } from ".";

export default {
  title: "Components/SimulationStreaming",
  component: SimulationStreaming,
};

export const Default = {
  args: {
    className: {},
    simulationStreamingClassName: {},
  },
};
